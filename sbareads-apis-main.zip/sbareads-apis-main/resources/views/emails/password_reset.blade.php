<!DOCTYPE html>
<html>
<head>
    <title>Password Reset Confirmation</title>
</head>
<body>
    <p>Hello {{ $name }},</p>
    <p>Your password was successfully reset at <strong>{{ $body }}</strong></p>
    <p>If you did not perform this action, please contact support immediately.</p>
</body>
</html>
