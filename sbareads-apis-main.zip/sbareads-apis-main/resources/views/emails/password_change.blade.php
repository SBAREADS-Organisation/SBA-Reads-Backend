<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Password Change Notification</title>
</head>
<body>
    <p>Hello {{ $name }},</p>
    <br>
    <p>{{ $body }}</p>
    <p>Thank you,<br>Your Support Team</p>
</body>
</html>
