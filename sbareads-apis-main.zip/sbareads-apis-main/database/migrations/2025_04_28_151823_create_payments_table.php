<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();

            $table->string('reference')->unique();
            $table->string('payment_intent_id')->unique()->nullable();
            $table->enum('status', ['pending', 'succeeded', 'failed', 'processing', 'refunded'])->default('pending');
            $table->string('currency', 10)->default('usd');
            $table->decimal('amount', 15, 2);
            // description
            $table->string('description')->nullable();
            $table->string('payment_provider')->default('stripe');
            $table->enum('type', ['purchase', 'earning', 'payout', 'refund', 'fee', 'others'])->default('debit');
            // purchased_by
            $table->foreignId('purchased_by')->nullable()->constrained('users')->nullOnDelete();

            // Polymorphic purpose
            $table->string('purpose_type'); // Example: App\Models\Order, App\Models\Subscription
            $table->string('purpose_id');

            $table->json('meta_data')->nullable();

            $table->timestampsTz(); // UTC timestamps
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
